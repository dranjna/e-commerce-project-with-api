import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { ProductLits } from "./redux/ProductSlice";
import { addtoCart, deleteCart } from "./redux/cartSliec";

export default function Product() {
  const listItem = useSelector((state) => state.list.item);
  const cartItem = useSelector((state) => state.cart.items);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(ProductLits());
  }, [dispatch]);

  return (
    <div className="bg-gray-50">
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold tracking-tight text-gray-900 mb-8 text-center">Fetch Api in Redux Toolkit</h2>

        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {listItem.map((item, index) => (
            <div key={index}>
              <div className="group relative bg-white p-4 rounded-xl shadow-md hover:shadow-xl transition-shadow duration-300">
                <div className="overflow-hidden rounded-lg">
                  <img src={item.images[0]} alt="" className="w-full h-60 object-cover rounded-lg transform group-hover:scale-105 transition-transform duration-300" />
                </div>

                <div className="mt-4 space-y-2">
                  <h3 className="text-sm font-semibold text-gray-800 truncate">{item.title}</h3>
                  <p className="text-gray-600 text-sm">Rating: ⭐ {item.rating}</p>
                  <p className="text-lg font-semibold text-gray-900">${item.price}</p>

                  {/* <button disabled className="w-full bg-red-600 text-white font-medium px-4 py-2 mt-2 rounded-lg cursor-not-allowed">
                    Remove Data
                  </button> */}
                  {cartItem.find((cartitem) => item.id === cartitem.id) ? (
                    <button onClick={() => dispatch(deleteCart(item))} className="w-full bg-red-600 text-white font-medium px-4 py-2 mt-2 rounded-lg">
                      Remove Data
                    </button>
                  ) : (
                    <button onClick={() => dispatch(addtoCart(item))} className="w-full bg-blue-500 hover:bg-blue-600 text-white font-medium px-4 py-2 mt-2 rounded-lg transition-colors duration-300">
                      Add to Cart
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
