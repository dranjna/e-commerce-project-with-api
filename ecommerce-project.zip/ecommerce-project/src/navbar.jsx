import { ShoppingCartIcon } from "@heroicons/react/24/outline";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
export default function Navbar() {
  const cartItem = useSelector((state) => state.cart.items);
  console.log("cart item", cartItem.length);
  return (
    <nav className="fixed top-0 left-0 w-full bg-white shadow-md z-50">
      <div className="max-w-7xl mx-auto px-4 py-3 flex justify-between items-center ">
        {/* Left: Logo or Site Name */}
        <h1 className="text-2xl font-bold text-blue-600">ShopEase</h1>

        {/* Center: Nav Links */}
        <div className="flex space-x-6">
          <Link to="/" className="text-gray-700 hover:text-blue-600 font-medium">
            Home
          </Link>
          <Link to="/product" className="text-gray-700 hover:text-blue-600 font-medium">
            Products
          </Link>
        </div>

        {/* Right: Cart Icon */}
        <Link to="/cart">
          <div className="relative">
            <ShoppingCartIcon className="h-7 w-7 text-gray-700 hover:text-blue-600 cursor-pointer" />

            <span className="absolute -top-1 -right-2 bg-red-500 text-white text-xs font-semibold rounded-full px-1.5">{cartItem.length ? cartItem.length : 0} </span>
          </div>
        </Link>
      </div>
    </nav>
  );
}
