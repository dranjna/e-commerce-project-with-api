import { createSlice } from "@reduxjs/toolkit";

const quantitySlice = createSlice({
  name: "quantity",
  initialState: {},
  reducers: {
    increament: (state, action) => {
      const id = action.payload;
      state[id] = (state[id] || 1) + 1;
    },
    decrement: (state, action) => {
      const id = action.payload;
      if (state[id] && state[id] > 1) {
        state[id] -= 1;
      }
    },
  },
});
export default quantitySlice.reducer;
export const { increament, decrement } = quantitySlice.actions;
