import { configureStore } from "@reduxjs/toolkit";
import productList from "./ProductSlice";
import cartData from "./cartSliec";
import qty from "./quantitySlice";
const store = configureStore({
  reducer: {
    list: productList,
    cart: cartData,
    qtyReducer: qty,
  },
});
export default store;
