import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
export const ProductLits = createAsyncThunk("productlist", async () => {
  const result = await fetch("https://dummyjson.com/products");
  const data = await result.json();
  return data.products;
});

const ProductSlice = createSlice({
  name: "productlist",
  initialState: {
    item: [],
    loader: false,
    error: null,
  },
  extraReducers: (bulider) => {
    bulider.addCase(ProductLits.pending, (state) => {
      state.loader = true;
    });
    bulider.addCase(ProductLits.fulfilled, (state, action) => {
      state.loader = false;
      state.item = action.payload;
    });
    bulider.addCase(ProductLits.rejected, (state) => {
      state.error = "There is some Problem";
    });
  },
});
export default ProductSlice.reducer;
