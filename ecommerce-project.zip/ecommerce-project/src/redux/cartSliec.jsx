import { createSlice } from "@reduxjs/toolkit";

const CartSlice = createSlice({
  name: "cart",
  initialState: {
    items: JSON.parse(localStorage.getItem("cart")) || [],
  },
  reducers: {
    addtoCart: (state, action) => {
      state.items.push(action.payload);
      localStorage.setItem("cart", JSON.stringify(state.items));
    },
    deleteCart: (state, action) => {
      const cartData = state.items.filter((item) => item.id !== action.payload.id);
      state.items = cartData;
      localStorage.setItem("cart", JSON.stringify(state.items));
    },
  },
});
export default CartSlice.reducer;
export const { addtoCart, deleteCart } = CartSlice.actions;
