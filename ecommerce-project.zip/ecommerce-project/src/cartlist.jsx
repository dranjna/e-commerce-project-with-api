import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { deleteCart } from "./redux/cartSliec";
import { decrement, increament } from "./redux/quantitySlice";

export default function CartPage() {
  const CartData = useSelector((state) => state.cart.items);
  const quatity = useSelector((state) => state.qtyReducer);
  console.log("quatity", quatity);
  const dispatch = useDispatch();
  // console.log("cartdata", CartData);
  const subTotal = CartData.reduce((accumulator, item) => {
    if (!item || !item.price) return accumulator;
    return accumulator + (quatity[item.id] || 1) * (item.price || 0);
  }, 0);
  const shipping = CartData.length > 0 ? 5.0 : 0;
  const totalPrice = subTotal + shipping;
  return (
    <div className="container mx-auto px-6 py-20">
      <h1 className="text-3xl font-bold mb-8 text-gray-800">🛒 Shopping Cart</h1>

      {/* <!-----Your cart is empty---> */}
      {CartData.length === 0 ? (
        <div className="flex flex-col items-center justify-center text-center mt-20">
          <img src="https://cdn-icons-png.flaticon.com/512/11329/11329060.png" alt="Empty Cart" className="w-40 mb-4 opacity-80" />
          <h2 className="text-xl font-semibold text-gray-700 mb-2">Your cart is empty</h2>
          <p className="text-gray-500">Looks like you haven't added anything to your cart yet.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* <!----- Cart Items---> */}

          <div className="md:col-span-2 space-y-6">
            {CartData.map((item, index) => (
              <div key={index} className="flex items-center justify-between p-5 border rounded-xl shadow-sm hover:shadow-lg transition">
                <img src={item.images[0]} alt="" className="w-20 h-20 object-cover rounded-lg" />

                <div className="flex-1 mx-4">
                  <h2 className="font-semibold text-gray-800">{item.title}</h2>
                  <p className="text-gray-500">$ {(quatity[item.id] || 1) * (item.price || 0).toFixed(2)} </p>

                  <div className="flex items-center mt-3 space-x-3">
                    <button onClick={() => dispatch(decrement(item.id))} className="px-3 py-1 bg-gray-200 hover:bg-gray-300 rounded">
                      -
                    </button>
                    <span className="text-gray-700 font-medium">{quatity[item.id] || 1}</span>
                    <button onClick={() => dispatch(increament(item.id))} className="px-3 py-1 bg-gray-200 hover:bg-gray-300 rounded">
                      +
                    </button>
                  </div>
                </div>

                <button onClick={() => dispatch(deleteCart(item))} className="text-red-500 hover:text-red-700 font-semibold">
                  Remove
                </button>
              </div>
            ))}
          </div>

          {/*Subtotal */}
          <div className="p-6 border rounded-xl shadow-md bg-gray-50">
            <h2 className="text-xl font-bold mb-6 text-gray-800">Order Summary</h2>

            <div className="space-y-3 text-gray-700">
              <p className="flex justify-between">
                <span>Subtotal</span>
                <span>{subTotal.toFixed(2)}</span>
              </p>
              <p className="flex justify-between">
                <span>Shipping</span>
                <span>{shipping.toFixed(2)}</span>
              </p>
              <hr />
              <p className="flex justify-between font-semibold text-lg">
                <span>Total</span>
                <span>{totalPrice.toFixed(2)}</span>
              </p>
            </div>

            <button className="mt-6 w-full bg-blue-600 text-white py-2.5 rounded-lg hover:bg-blue-700 transition">Proceed to Checkout</button>
          </div>
        </div>
      )}
    </div>
  );
}
