import { BrowserRouter, Route, Routes } from "react-router";
import "./App.css";

import Navbar from "./navbar";
import Product from "./productList";
import CartPage from "./cartlist";

function App() {
  return (
    <>
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path="/" element={<Product />} />
          <Route path="/product" element={<Product />} />
          <Route path="/cart" element={<CartPage />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
